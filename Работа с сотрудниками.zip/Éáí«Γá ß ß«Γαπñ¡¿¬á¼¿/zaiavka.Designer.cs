﻿
namespace Работа_с_сотрудниками
{
    partial class zaiavka
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(zaiavka));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.crewatezai = new System.Windows.Forms.Button();
            this.fio = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.nextzai = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tema = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(508, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(484, 36);
            this.label1.TabIndex = 7;
            this.label1.Text = "Обращение/подача заявления директору";
            this.label1.UseCompatibleTextRendering = true;
            this.label1.UseWaitCursor = true;
            // 
            // crewatezai
            // 
            this.crewatezai.BackColor = System.Drawing.Color.Brown;
            this.crewatezai.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.crewatezai.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.crewatezai.Location = new System.Drawing.Point(178, 183);
            this.crewatezai.Name = "crewatezai";
            this.crewatezai.Size = new System.Drawing.Size(122, 39);
            this.crewatezai.TabIndex = 8;
            this.crewatezai.Text = "Создать";
            this.crewatezai.UseVisualStyleBackColor = false;
            this.crewatezai.Click += new System.EventHandler(this.crewatezai_Click);
            // 
            // fio
            // 
            this.fio.Location = new System.Drawing.Point(258, 92);
            this.fio.Name = "fio";
            this.fio.Size = new System.Drawing.Size(119, 20);
            this.fio.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(106, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 30);
            this.label2.TabIndex = 10;
            this.label2.Text = "ФИО и число";
            this.label2.UseCompatibleTextRendering = true;
            this.label2.UseWaitCursor = true;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // nextzai
            // 
            this.nextzai.BackColor = System.Drawing.Color.Brown;
            this.nextzai.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nextzai.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nextzai.Location = new System.Drawing.Point(178, 247);
            this.nextzai.Name = "nextzai";
            this.nextzai.Size = new System.Drawing.Size(122, 39);
            this.nextzai.TabIndex = 11;
            this.nextzai.Text = "Отправить";
            this.nextzai.UseVisualStyleBackColor = false;
            this.nextzai.Click += new System.EventHandler(this.nextzai_Click);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.Brown;
            this.exit.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.exit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.exit.Location = new System.Drawing.Point(12, 279);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(109, 31);
            this.exit.TabIndex = 26;
            this.exit.Text = "На главную";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(77, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 30);
            this.label3.TabIndex = 28;
            this.label3.Text = "Тема обращения";
            this.label3.UseCompatibleTextRendering = true;
            this.label3.UseWaitCursor = true;
            // 
            // tema
            // 
            this.tema.Location = new System.Drawing.Point(258, 132);
            this.tema.Name = "tema";
            this.tema.Size = new System.Drawing.Size(119, 20);
            this.tema.TabIndex = 27;
            this.tema.TextChanged += new System.EventHandler(this.tema_TextChanged);
            // 
            // zaiavka
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 321);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tema);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.nextzai);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.fio);
            this.Controls.Add(this.crewatezai);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "zaiavka";
            this.Text = "Подать заявку";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button crewatezai;
        private System.Windows.Forms.TextBox fio;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button nextzai;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tema;
    }
}
﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
namespace Работа_с_сотрудниками
{
    public partial class zaiavka : Form
    {
        public zaiavka()
        {            InitializeComponent();        }
        private void crewatezai_Click(object sender, EventArgs e)
        {
            if (fio.Text == "")
            {
                MessageBox.Show("Как минимум одно из полей пустое");
                fio.Clear();
                tema.Clear();             
            }
            else
            {
                FileStream fileStream = File.Create(@"C:\Users\user.ALCOLLEGE\Desktop\" + tema.Text + fio.Text + ".docx");
                fileStream.Close();
                Process.Start(@"C:\Users\user.ALCOLLEGE\Desktop\" + tema.Text + fio.Text + ".docx");
            }        }
        private void label2_Click(object sender, EventArgs e)
        {        }
        private void nextzai_Click(object sender, EventArgs e)
        {     System.Diagnostics.Process.Start("http://mail.google.com");        }
        private void exit_Click(object sender, EventArgs e)
        {   viborsotr fr2 = new viborsotr();
            fr2.Show();
            Hide();        }
        private void tema_TextChanged(object sender, EventArgs e)
        {        }    } }

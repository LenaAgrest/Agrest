﻿namespace Работа_с_сотрудниками
{


    partial class SotrudnikiDataSet1
    {
    }
}

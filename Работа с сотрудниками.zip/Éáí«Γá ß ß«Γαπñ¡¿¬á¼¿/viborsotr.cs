﻿using System;
using System.Windows.Forms;
namespace Работа_с_сотрудниками
{
    public partial class viborsotr : Form
    {
        public viborsotr()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {   zaiavka fr2 = new zaiavka();
            fr2.Show();
            Hide();        }
        private void button2_Click(object sender, EventArgs e)
        {   calc fr2 = new calc();
            fr2.Show();
            Hide();        }
        private void button3_Click(object sender, EventArgs e)
        {
            Вход fr2 = new Вход();
            fr2.Show();
            Hide();
        }    }}
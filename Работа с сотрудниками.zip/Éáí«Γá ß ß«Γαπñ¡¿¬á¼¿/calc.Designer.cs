﻿
namespace Работа_с_сотрудниками
{
    partial class calc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(calc));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lastdays = new System.Windows.Forms.TextBox();
            this.zp = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.checklastdays = new System.Windows.Forms.CheckBox();
            this.lab = new System.Windows.Forms.Label();
            this.premia = new System.Windows.Forms.CheckBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.alcotrBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sotrudnikiDataSet = new Работа_с_сотрудниками.SotrudnikiDataSet1();
            this.alcotrTableAdapter = new Работа_с_сотрудниками.SotrudnikiDataSet1TableAdapters.AlcotrTableAdapter();
            this.otpusk = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.bolnichnii = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.exit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.alcotrBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrudnikiDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(358, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(70, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(235, 36);
            this.label1.TabIndex = 7;
            this.label1.Text = "Калькулятор з/п";
            // 
            // lastdays
            // 
            this.lastdays.Location = new System.Drawing.Point(16, 176);
            this.lastdays.Name = "lastdays";
            this.lastdays.Size = new System.Drawing.Size(153, 20);
            this.lastdays.TabIndex = 8;
            this.lastdays.TextChanged += new System.EventHandler(this.lastdays_TextChanged);
            this.lastdays.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.lastdays_KeyPress);
            // 
            // zp
            // 
            this.zp.Location = new System.Drawing.Point(193, 233);
            this.zp.Name = "zp";
            this.zp.Size = new System.Drawing.Size(103, 20);
            this.zp.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(15, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 19);
            this.label2.TabIndex = 12;
            this.label2.Text = "Пропущенные дни";
            // 
            // checklastdays
            // 
            this.checklastdays.AutoSize = true;
            this.checklastdays.Location = new System.Drawing.Point(154, 158);
            this.checklastdays.Name = "checklastdays";
            this.checklastdays.Size = new System.Drawing.Size(15, 14);
            this.checklastdays.TabIndex = 13;
            this.checklastdays.UseVisualStyleBackColor = true;
            // 
            // lab
            // 
            this.lab.AutoSize = true;
            this.lab.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lab.Location = new System.Drawing.Point(12, 211);
            this.lab.Name = "lab";
            this.lab.Size = new System.Drawing.Size(61, 19);
            this.lab.TabIndex = 14;
            this.lab.Text = "Премия";
            // 
            // premia
            // 
            this.premia.AutoSize = true;
            this.premia.Location = new System.Drawing.Point(79, 213);
            this.premia.Name = "premia";
            this.premia.Size = new System.Drawing.Size(15, 14);
            this.premia.TabIndex = 15;
            this.premia.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Продавец",
            "Кладовщик",
            "Курьер"});
            this.comboBox1.Location = new System.Drawing.Point(101, 123);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(134, 21);
            this.comboBox1.TabIndex = 16;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // alcotrBindingSource
            // 
            this.alcotrBindingSource.DataMember = "Alcotr";
            this.alcotrBindingSource.DataSource = this.sotrudnikiDataSet;
            // 
            // sotrudnikiDataSet
            // 
            this.sotrudnikiDataSet.DataSetName = "SotrudnikiDataSet";
            this.sotrudnikiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // alcotrTableAdapter
            // 
            this.alcotrTableAdapter.ClearBeforeFill = true;
            // 
            // otpusk
            // 
            this.otpusk.AutoSize = true;
            this.otpusk.Location = new System.Drawing.Point(79, 249);
            this.otpusk.Name = "otpusk";
            this.otpusk.Size = new System.Drawing.Size(15, 14);
            this.otpusk.TabIndex = 19;
            this.otpusk.UseVisualStyleBackColor = true;
            this.otpusk.CheckedChanged += new System.EventHandler(this.otpusk_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(12, 244);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 19);
            this.label3.TabIndex = 18;
            this.label3.Text = "Отпуск";
            // 
            // bolnichnii
            // 
            this.bolnichnii.AutoSize = true;
            this.bolnichnii.Location = new System.Drawing.Point(117, 282);
            this.bolnichnii.Name = "bolnichnii";
            this.bolnichnii.Size = new System.Drawing.Size(15, 14);
            this.bolnichnii.TabIndex = 21;
            this.bolnichnii.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(15, 277);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 19);
            this.label4.TabIndex = 20;
            this.label4.Text = "Больничный";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(97, 101);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 19);
            this.label5.TabIndex = 22;
            this.label5.Text = "Выберите должность";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Brown;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(16, 307);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 38);
            this.button2.TabIndex = 23;
            this.button2.Text = "Готово";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(212, 208);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 19);
            this.label6.TabIndex = 24;
            this.label6.Text = "Ваша з/п";
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.Brown;
            this.exit.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.exit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.exit.Location = new System.Drawing.Point(228, 307);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(118, 38);
            this.exit.TabIndex = 25;
            this.exit.Text = "На главную";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // calc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(358, 357);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.bolnichnii);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.otpusk);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.premia);
            this.Controls.Add(this.lab);
            this.Controls.Add(this.checklastdays);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.zp);
            this.Controls.Add(this.lastdays);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "calc";
            this.Text = "Калькулятор";
            this.Load += new System.EventHandler(this.calc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.alcotrBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrudnikiDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lastdays;
        private System.Windows.Forms.TextBox zp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checklastdays;
        private System.Windows.Forms.Label lab;
        private System.Windows.Forms.CheckBox premia;
        private System.Windows.Forms.ComboBox comboBox1;
        private SotrudnikiDataSet1 sotrudnikiDataSet;
        private System.Windows.Forms.BindingSource alcotrBindingSource;
        private SotrudnikiDataSet1TableAdapters.AlcotrTableAdapter alcotrTableAdapter;
        private System.Windows.Forms.CheckBox otpusk;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox bolnichnii;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button exit;
    }
}
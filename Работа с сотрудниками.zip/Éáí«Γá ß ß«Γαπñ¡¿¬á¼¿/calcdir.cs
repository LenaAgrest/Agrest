﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Работа_с_сотрудниками
{
    public partial class calcdir : Form
    {
        public calcdir()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            const int d = 500;
            int c = int.Parse(lastdays.Text);
            int s = default(int);
            int p = default(int);
            int o = default(int);
            if (comboBox1.Text == "Продавец")
            {
                s = 33000;
                p = 5000;
                o = 15000;
            }
            if (comboBox1.Text == "Кладовщик")
            {
                s = 35000;
                p = 7000;
                o = 17000;
            }
            if (comboBox1.Text == "Курьер")
            {
                s = 25000;
                p = 2500;
                o = 12000;
            }
            if (checklastdays.Checked == true)
            {
                s = s - (c * d);
            }
            if (premia.Checked == true)
            {
                s = s + p;
            }
            if (otpusk.Checked == true)
            {
                s = s - o;
            }
            if (bolnichnii.Checked == true)
            {
                s = s - o;
            }
            zp.Text = s.ToString();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            vibordir fr2 = new vibordir();
            fr2.Show();
            Hide();
        }

        private void lastdays_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;

            if (!Char.IsDigit(number))
            {
                e.Handled = true;
            }
        }
    }
}

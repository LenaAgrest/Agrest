﻿using System;
using System.Windows.Forms;

namespace Работа_с_сотрудниками
{
    public partial class vibordir : Form
    {
        public vibordir()
        { 
            InitializeComponent(); 
        }
        private void button1_Click(object sender, EventArgs e)
        {   
            prosmdir fr2 = new prosmdir();
            fr2.Show();
            Hide();        
        }
        private void button2_Click(object sender, EventArgs e)
        {   
            gorod fr2 = new gorod();
            fr2.Show();
            Hide();        
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Вход fr2 = new Вход();
            fr2.Show();
            Hide();
        }
        private void button4_Click(object sender, EventArgs e)
        {   calc fr2 = new calc();
            fr2.Show();
            Hide();
        }    
    }
}

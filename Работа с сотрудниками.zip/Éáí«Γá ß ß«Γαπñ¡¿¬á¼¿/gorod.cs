﻿using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Работа_с_сотрудниками
{
    public partial class gorod : Form
    {
        DataSet ds;
        SqlDataAdapter adapter;
        SqlCommandBuilder commandBuilder;
        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Sotrudniki;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        string sql = "SELECT * FROM Alcotr";
        DataTable dt = new DataTable();
        public gorod()
        {
            InitializeComponent();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.AllowUserToAddRows = false;
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {        }
        private void gorod_Load(object sender, EventArgs e)
        {        }
        private void button1_Click(object sender, EventArgs e)
        {            }
        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {   }
        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {        }
        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                adapter = new SqlDataAdapter(sql, connection);
                ds = new DataSet();
                adapter.Fill(ds);
                this.dataGridView1.Sort(this.dataGridView1.Columns["Город"], ListSortDirection.Ascending);
            }        }
        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {        }
        private void button3_Click(object sender, EventArgs e)
        {            }
        private void alcotrDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {        }
        private void bircotrDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {        }
        private void dataGridView1_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
        {        }
        private void fillByToolStripButton_Click_1(object sender, EventArgs e)
        {
            try
            {
                this.alcotrTableAdapter.FillBy(this.sotrudnikiDataSet1.Alcotr);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {        }
        private void alcotrDataGridView_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {        }
        private void save_Click(object sender, EventArgs e)
        {        }
        private void nazad_Click(object sender, EventArgs e)
        {
            vibordir fr2 = new vibordir();
            fr2.Show();
            Hide();
        }
        private void save_Click_1(object sender, EventArgs e)
        {
            DataRow row = ds.Tables[0].NewRow(); // добавляем новую строку в DataTable
            ds.Tables[0].Rows.Add(row);
        }
        private void button3_Click_1(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    adapter = new SqlDataAdapter(sql, connection);
                    commandBuilder = new SqlCommandBuilder(adapter);
                    adapter.InsertCommand = new SqlCommand("sp_CreateAlcotr", connection);
                    adapter.InsertCommand.CommandType = CommandType.StoredProcedure;
                    adapter.InsertCommand.Parameters.Add(new SqlParameter("@Id", SqlDbType.Int, 0, "Id"));
                    adapter.InsertCommand.Parameters.Add(new SqlParameter("@ФИО_сотрудника", SqlDbType.NVarChar, 50, "ФИО_сотрудника"));
                    adapter.InsertCommand.Parameters.Add(new SqlParameter("@Город", SqlDbType.NVarChar, 10, "Город"));
                    adapter.InsertCommand.Parameters.Add(new SqlParameter("@Должность", SqlDbType.NVarChar, 15, "Должность"));
                    adapter.InsertCommand.Parameters.Add(new SqlParameter("@Эл_почта", SqlDbType.NVarChar, 50, "Эл_почта"));
                    adapter.InsertCommand.Parameters.Add(new SqlParameter("@Оклад", SqlDbType.Int, 0, "Оклад"));
                    adapter.Update(ds);
                    MessageBox.Show("Изменения сохранены!");
                }            }
            catch
            {    MessageBox.Show("Внести не удалось");     }        }    } }
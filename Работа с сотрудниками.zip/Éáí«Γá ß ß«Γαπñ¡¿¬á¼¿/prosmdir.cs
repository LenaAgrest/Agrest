﻿using System;
using System.Windows.Forms;
namespace Работа_с_сотрудниками
{
    public partial class prosmdir : Form
    {
        public prosmdir()
        {
            InitializeComponent();
        }
        private void exit_Click(object sender, EventArgs e)
        {
            vibordir fr2 = new vibordir();
            fr2.Show();
            Hide();
        }
        private void prosmdir_Load(object sender, EventArgs e)
        {        }
        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://mail.google.com");
        }
    }
}

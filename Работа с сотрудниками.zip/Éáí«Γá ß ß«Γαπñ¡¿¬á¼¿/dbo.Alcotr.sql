﻿CREATE TABLE [dbo].[Alcotr] (
    [Id]               INT           NOT NULL,
    [ФИО_сотрудника]   NVARCHAR (50) NULL,
    [Город]            NVARCHAR (10) NULL,
    [КодДолжности]        INT NULL,
    [Эл_почта]         NVARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC), 
    CONSTRAINT [Al] FOREIGN KEY ([КодДолжности]) REFERENCES [Alcotr]([КодДолжности]) 
);


﻿using System;
using System.Windows.Forms;
namespace Работа_с_сотрудниками
{
    public partial class Вход : Form
    {
        public Вход()
        {
            InitializeComponent();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            passsot.Visible = true;
            vxodsot.Visible = true;
        }
        private void passdir_TextChanged(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.SetToolTip(passdir, "Введите пароль");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            passdir.Visible = true;
            button3.Visible = true;            
        }
        private void passsot_TextChanged(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.SetToolTip(passdir, "Введите пароль");
        }
        private void vxodsot_Click(object sender, EventArgs e)
        {   
            if (passsot.Text != "")
            {
                if (passsot.Text == "imsot")
                {
                    viborsotr fr2 = new viborsotr();
                    fr2.Show();
                    Hide();
                }
                else
                {
                    MessageBox.Show("Неправильный пароль");
                    passsot.Clear();
                }            }
            else
            {
                MessageBox.Show("Введите пароль");
            }        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (passdir.Text != "")
            {
                if (passdir.Text == "sach")
                {
                    vibordir fr2 = new vibordir();
                    fr2.Show();
                    Hide();
                }
                else
                {
                    MessageBox.Show("Неправильный пароль");
                    passdir.Clear();
                }            }
            else
            {MessageBox.Show("Введите пароль");}        }
        private void Вход_Load(object sender, EventArgs e)
        {    }}}
